package execution;

import java.util.Scanner;

import dao.CustomerDAO;
import dao.CustomerDAOImpl;
import domain.Customer;

public class Execution {

	public static void main(String[] args) {
		Customer customer=new Customer();
		CustomerDAO customerDAO=new CustomerDAOImpl();
		System.out.println("100-record level validation");
		System.out.println("101-file level validation");
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your choice");
		int choice=sc.nextInt();
		customerDAO.saveCustomer(customer,choice);
		
		
		
	}

}
