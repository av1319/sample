package dao;

import domain.Customer;

public interface CustomerDAO {
	public void saveCustomer(Customer customer,int choice);
public void deleteCustomer(Customer customer);
}
