package dao;

import java.util.regex.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;






import validation.CustomerValidation;
import connection.ConnectionSetup;
import domain.Customer;

public class CustomerDAOImpl implements CustomerDAO {

	@Override
	public void saveCustomer(Customer customer,int choice) {
		ConnectionSetup connectionSetup=new ConnectionSetup();
		Connection con=connectionSetup.getConnection();
		FileReader fileReader=null;
		FileWriter fileWriter=null;
		PrintWriter printWriter = null;
		BufferedReader bufferReader=null;
		PreparedStatement pstmt=null;
		int flag=0;
			try {
				String fileName="testCase2.txt";
				CustomerValidation customerValidation= new CustomerValidation();
				
				if(customerValidation.isValidFileFormat(fileName))
				{
				fileReader = new FileReader(fileName);
				bufferReader = new BufferedReader(fileReader);
				String l = bufferReader.readLine();
				while(l!=null)
				{
					flag=0;
					 String [] arrOfStr = l.split("~",-1);	
					 //customer.setCustomer_Code(arrOfStr[0]);
					// System.out.println(arrOfStr[0]+" 1111111");
					 if(customerValidation.isPrimary_Key(arrOfStr[0], 10))
					 {
					  customer.setCustomer_Code(arrOfStr[0]);
					  System.out.println(arrOfStr[0]+" 1");
					 }
					 else
					 {
						 flag++;
					 }
					
					 if(customerValidation.isValid_String("arrOfStr[1]", 30, true))
					 {
						 
						 customer.setCustomer_Name(arrOfStr[1]);
						 System.out.println(arrOfStr[1]+" 2");
					 }
					 else
					 {
						 System.out.println("byy"+flag);
						 customer.setCustomer_Name(arrOfStr[1]);
						 flag++;

					 }
					// System.out.println(flag+" aa");
					 if(customerValidation.isValid_String(arrOfStr[2], 100, true))
					 {
						 customer.setCustomer_Address_1(arrOfStr[2]);
						 System.out.println(arrOfStr[2]+" 3");
					 }
					 else
					 {
						 customer.setCustomer_Address_1(arrOfStr[2]);
						 flag++;

					 }

					 if(customerValidation.isValid_String(arrOfStr[3], 100))
					 {
						 customer.setCustomer_Address_2(arrOfStr[3]);
						 System.out.println(arrOfStr[3]+" 4");
					 }
					 else
					 {
						 customer.setCustomer_Address_2(arrOfStr[3]);
						 flag++;

					 }

					 if(customerValidation.isvalidCustomer_Pin_Code(Long.parseLong(arrOfStr[4]),6))
					 {
						 customer.setCustomer_Pin_Code(Long.parseLong(arrOfStr[4]));
						 System.out.println(arrOfStr[4]+" 5");
					 }
						 else
					 {		
							 customer.setCustomer_Pin_Code(Long.parseLong(arrOfStr[4]));
						 flag++;
					 } 
					 if(customerValidation.isValidEmail_Address(arrOfStr[5],100))
					 {
						 customer.setEmail_address(arrOfStr[5]);
						 System.out.println(arrOfStr[5]+" 6");
					 }
						 else
					 {
							 customer.setEmail_address(arrOfStr[5]);
						 flag++;

					 } 
					 if(customerValidation.isValidContact_Number(Long.parseLong(arrOfStr[6]), 20))
					 {
						 customer.setContact_Number(Long.parseLong(arrOfStr[6]));
						 System.out.println(arrOfStr[6]+" 7");
					 }
						 else
					 {
							 customer.setContact_Number(Long.parseLong(arrOfStr[6]));
						 flag++;

					 } 	 
					
					 if(customerValidation.isValid_String(arrOfStr[7],100,true))
					 {
						 customer.setPrimary_Contact_Person(arrOfStr[7]);
						 System.out.println(arrOfStr[7]+" 8");
					 }
						 else
					 {
							 customer.setPrimary_Contact_Person(arrOfStr[7]);
						 flag++;

					 }
					  if(customerValidation.isValidRecord_Status(arrOfStr[8]))
						 {
						  customer.setRecord_Status(arrOfStr[8]);
						  System.out.println(arrOfStr[8]+" 9");
						 }
							 else
						 {	
								 customer.setRecord_Status(arrOfStr[8]);
							 flag++;
						 }
				
					  if(customerValidation.isValidActiveInactive_Flag(arrOfStr[9]))
						 {
						  customer.setActiveInactive_Flag(arrOfStr[9]);
						  System.out.println(arrOfStr[9]+" 10");
						 }
							 else
						 {
							 flag++;

						 }
					  if(customerValidation.isValidDate(arrOfStr[10]))
						 {
						  customer.setCreate_Date(arrOfStr[10]);
						  System.out.println(arrOfStr[10]+" 11");
						 }
							 else
						 {
								 customer.setCreate_Date(arrOfStr[10]);
							 flag++;

						 }
					
					  if(customerValidation.isValid_String(arrOfStr[11], 30, true))
						 {
						  customer.setCreated_By(arrOfStr[11]);
						  System.out.println(arrOfStr[11]+" 12");
						 }
							 else							
						 {
								 customer.setCreated_By(arrOfStr[11]);
							 flag++;
						 }

					  customer.setModified_Date(arrOfStr[12]);
					  System.out.println(arrOfStr[12]+" 13");
					 
					  
					  if(customerValidation.isValid_String(arrOfStr[13], 30))
						 {
						  customer.setModified_By(arrOfStr[13]);
						  System.out.println(arrOfStr[13]+" 14");
						 }
							 else
						 {
								 customer.setModified_By(arrOfStr[13]);
							 flag++;
						 }
					  
					  customer.setAuthorized_Date(arrOfStr[14]);
					  System.out.println(arrOfStr[14]+" 15");
					
  
					if(customerValidation.isValid_String(arrOfStr[15], 30))
						 {
						customer.setAuthorized_By(arrOfStr[15]);
						System.out.println(arrOfStr[15]+" 16");
						 }
							 else
						 {
								 customer.setAuthorized_By(arrOfStr[15]);
							 flag++;
						 }
					if(choice==100)
					{
					if(flag==0)
					{
						System.out.println("Flag "+flag);
					 pstmt=con.prepareStatement("insert into table100brd values(seq_100.nextval,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
					 pstmt.setString(1, customer.getCustomer_Code());
					 pstmt.setString(2, customer.getCustomer_Name());
					 pstmt.setString(3, customer.getCustomer_Address_1());
					 pstmt.setString(4, customer.getCustomer_Address_2());
					 pstmt.setLong(5, customer.getCustomer_Pin_Code());
					 pstmt.setString(6, customer.getEmail_address());
					 pstmt.setLong(7, customer.getContact_Number());
					 pstmt.setString(8, customer.getPrimary_Contact_Person());
					 pstmt.setString(9, customer.getRecord_Status());
					 pstmt.setString(10, customer.getActiveInactive_Flag());
					 pstmt.setString(11, customer.getCreate_Date());
					 pstmt.setString(12, customer.getCreated_By());
					 pstmt.setString(13, customer.getModified_Date());
					 pstmt.setString(14, customer.getModified_By());
					 pstmt.setString(15, customer.getAuthorized_Date());
					 pstmt.setString(16, customer.getAuthorized_By());
					 pstmt.executeUpdate();
					 System.out.println("done");
					}
					
					else
					{
						System.out.println("Flag "+flag);
						
						fileWriter=new FileWriter("Errorlog1.txt",true);
						printWriter = new PrintWriter(fileWriter);
						//printWriter.write(customer.getCustomer_ID() + "\n"+customer.getCustomer_Code()+ "\n"+customer.getCustomer_Name()+ "\n"+customer.getCustomer_Address_1()+ "\n"+customer.getCustomer_Address_2()+ "\n"+customer.getCustomer_Pin_Code()+ "\n"+customer.getEmail_address()+ "\n"+customer.getContact_Number()+ "\n"+customer.getPrimary_Contact_Person()+ "\n"+customer.getRecord_Status()+ "\n"+customer.getActiveInactive_Flag()+ "\n"+customer.getCreate_Date()+ "\n"+customer.getCreated_By()+ "\n"+customer.getModified_By()+ "\n"+customer.getModified_By()+ "\n"+customer.getModified_Date()+ "\n"+customer.getAuthorized_By()+ "\n"+customer.getAuthorized_Date());
						printWriter.write(customer.getCustomer_ID() + " "+customer.getCustomer_Code()+ " "+customer.getCustomer_Name()+ " "+customer.getCustomer_Address_1()+ " "+customer.getCustomer_Address_2()+ " "+customer.getCustomer_Pin_Code()+ " "+customer.getEmail_address()+ " "+customer.getContact_Number()+ " "+customer.getPrimary_Contact_Person()+ " "+customer.getRecord_Status()+ " "+customer.getActiveInactive_Flag()+ " "+customer.getCreate_Date()+ " "+customer.getCreated_By()+ " "+customer.getModified_By()+ " "+customer.getModified_By()+ " "+customer.getModified_Date()+ " "+customer.getAuthorized_By()+ " "+customer.getAuthorized_Date());
						printWriter.flush();
						System.out.println("Error file");
					}
					 l = bufferReader.readLine();
					}
					else
					{
//						fileWriter=new FileWriter("Errorlog2.txt",true);
//						printWriter = new PrintWriter(fileWriter);
						//FileInputStream instream = null;
						//FileOutputStream outstream = null;
						try
						{
						pstmt=con.prepareStatement("truncate table table100brd");
						pstmt.executeUpdate();
						File infile =new File("testCase2.txt");
			    	    File outfile =new File("Errorlog2.txt");
			    	    FileInputStream instream = new FileInputStream(infile);
						FileOutputStream outstream = new FileOutputStream(outfile);
						byte[] buffer = new byte[1024];
						int length;
						while ((length = instream.read(buffer)) > 0)
							{
				    	    	outstream.write(buffer, 0, length);
				    	    }
						instream.close();
				    	outstream.close();
				    	System.exit(0);
//						pstmt=con.prepareStatement("truncate table table100brd");
					
						}
						catch(IOException ioe)
						{
				    		ioe.printStackTrace();
						}
					}
				}
				}
				else
					System.out.println("Invalid file Format");
					System.exit(0);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} catch(SQLException e)
			{
				e.printStackTrace();
			}
			
			
		
	}

	@Override
	public void deleteCustomer(Customer customer) {
		// TODO Auto-generated method stub
		
	}

	
	
}
