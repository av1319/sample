package validation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import connection.ConnectionSetup;

public class CustomerValidation {

public boolean isValidRecord_Status(String Record_Status)
{
	if(Record_Status!=null)
	{
		
		if(Record_Status.equals("A")||Record_Status.equals("M")||Record_Status.equals("D")||Record_Status.equals("N")||Record_Status.equals("R"))
		{
			
			return true;
		}
	}
	System.out.println("valid status error");
	return false;
}
///////////////////////////////////
///////////////////////////////////
public boolean isValidActiveInactive_Flag(String ActiveInactive_Flag)
{
	if(ActiveInactive_Flag!=null)
	{
		if(ActiveInactive_Flag.equals("A")||ActiveInactive_Flag.equals("I"))
		{
			return true;
		}
	}
	System.out.println("valid flag error");

	return false;
}
//public boolean isValid_String(String string,int size,boolean mandatory)
//{
//	String regex = "[a-zA-Z0-9]+";
//
//	if(mandatory==true)
//	{
//		System.out.println("12");
//	
//		if(string!=null)
//		{
//			System.out.println("13");
//				if(string.length()<=size)
//				{
//					if(string.matches("[a-zA-Z0-9]"))
//				{
//					
//					System.out.println("11");
//					return true;
//					
//				}
//
//				
//			}
//
//			
//		}
//
//		System.out.println("14");
//		return false;
//	}
//	else 
//		if(mandatory==false)
//		{
//		if(string!=null)
//		{
//			if(string.matches("^[a-zA-Z0-9]+$"))
//			{
//				if(string.length()<=size)
//				{
//					return true;
//				}
//				return false;
//			}
//			return false;
//		}
//		}
//	return true;
//	
//}

public boolean isValid_String(String string,int size,boolean mandatory)
{
//	String regex = "[a-zA-Z0-9]+";

	if(mandatory==true)
	{
	
		if(string!=null)
		{
				if(string.length()<=size)
				{
					char[] chars=string.toCharArray();
					for(char xyz:chars)
					{
						if((Character.isLetterOrDigit(xyz)))
						{
							String ch=Character.toString(xyz);
							return true;
						}
					}
				
				}	
		}
		System.out.println("valid String error "+string);

		return false;
	}
	else 
		if(mandatory==false)
		{
		if(string!=null)
		{
			if(string.length()<=size)
			{
				char[] chars=string.toCharArray();
				for(char xyz:chars)
				{
					if((Character.isLetterOrDigit(xyz)))
					{
						String ch=Character.toString(xyz);
						return true;
					}
					System.out.println("valid String error "+string);
					return false;
				}
			
			}
		}
		}
	return true;
	
}

///////////////////////////////////////////////////
//////////////////////////////////////////////////
public boolean isValid_String(String string,int size)
{
	if(string!=null)
	{
		if(string.length()<=size)
		{
			char[] chars=string.toCharArray();
			for(char xyz:chars)
			{
				if((Character.isLetterOrDigit(xyz)))
				{
					String ch=Character.toString(xyz);
					return true;
				}
				System.out.println("valid String error "+string);
				return false;
			}
		
		}
	}
	return true;
	
}
///////////////////////////////////
//////////////////////////////
public boolean isValidContact_Number(long string,int size)
{
	
	String mno=String.valueOf(string);
	if(mno!=null)
	{
		if(mno.length()<=size)
		{
			char[] chars=mno.toCharArray();
			for(char xyz:chars)
			{
				if((Character.isDigit(xyz)))
				{
					String ch=Character.toString(xyz);
						return true;
					
				}
				System.out.println("valid contact error "+string);
				return false;
			}
		
		}
	}
	return true;
}


//////////////////////////////////

///////////////////////////////////
public boolean isvalidCustomer_Pin_Code(long num,int size)
{

	String mno=String.valueOf(num);
	if(mno!=null)
	{
		if(mno.length()<=size)
		{
			char[] chars=mno.toCharArray();
			for(char xyz:chars)
			{
				if((Character.isDigit(xyz)))
				{
					String ch=Character.toString(xyz);
						return true;
					
				}
				System.out.println("valid customer pin code error "+num);
				return false;
			}
		
		}
	}
	return false;
}





//////////////////////////////////////
public boolean isValidEmail_Address(String email,int size)
{
    String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+
                        "[a-zA-Z0-9_+&*-]+)*@" +
                        "(?:[a-zA-Z0-9-]+\\.)+[a-z" +
                        "A-Z]{2,7}$";
                 
    if(email!=null)
    {
    	if(email.length()<=size)
    	{
    	if(String.valueOf(email).matches(emailRegex))
    	{
    		return true;
    	}
    	System.out.println("valid email error "+email);
    	return false;
    	}
    }System.out.println("valid email error "+email);
    return false;
}
//////////////////////////////////////////
//////////////////////////////////////////
public boolean isValidDate(String date)
{
	if(date!=null)
		return true;
	return false;
}
///////////////////////////////////////////

//////////////////////////////////
public boolean isValidFileFormat(String string)
{
	if(string.contains(".txt"))
	{
		return true;
	}
	return false;
}

//public boolean isPrimary_Key(String string,int size)
//{
//	if(string!=null)
//	{
//		if(string.length()<=size)
//		{
//			char[] chars=string.toCharArray();
//			for(char xyz:chars)
//			{
//				if((Character.isLetterOrDigit(xyz)))
//				{
//					String ch=Character.toString(xyz);
//					ConnectionSetup connectionSetup=new ConnectionSetup();
//					Connection con=connectionSetup.getConnection();
//					try
//					{
//						PreparedStatement pstmt = con.prepareStatement("select * from table100brd"); 
//						ResultSet rs=pstmt.executeQuery();
//							while(rs.next())
//							{
//								String primary_key=rs.getString(2);
//								if(primary_key.equals(ch))
//								{
//									System.out.println("primary Key already present with same name");
//									return false;
//								}
//								return true;
//							}
//					}
//					catch (SQLException e) 
//					{
//						e.printStackTrace();
//					}
//				
//				}
//			}
//		
//		}
//	}
//	return false;
//}
////////////////////////////////////////
//////////////////////////////////////
public boolean isPrimary_Key(String string,int size)
{
	String mno=String.valueOf(string);
	if(mno!=null)
	{
		if(mno.length()<=size)
		{
			char[] chars=mno.toCharArray();
			for(char xyz:chars)
			{
				if((Character.isDigit(xyz)))
				{
					String ch=Character.toString(xyz);
						return true;
					
				}
				
			}
		
		}
	}	System.out.println("valid primarykey error1 "+string);
	return false;
}

}
